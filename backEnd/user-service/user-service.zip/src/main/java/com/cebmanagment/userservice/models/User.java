package com.cebmanagment.userservice.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    //The unique identifier for the user.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    //The username of the user, used for authentication.
    private String username;
    //The email address of the user, which must be unique.
    private String email;
    // The encrypted password of the user, required for authentication.
    @Column(nullable = false)
    private String password;
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(
            name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();


}
