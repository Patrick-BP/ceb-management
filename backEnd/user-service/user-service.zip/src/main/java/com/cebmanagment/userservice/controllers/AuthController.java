package com.cebmanagment.userservice.controllers;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.cebmanagment.userservice.security.jwt.JwtUtils;
import com.cebmanagment.userservice.dto.JwtResponse;
import com.cebmanagment.userservice.dto.LoginRequest;
import com.cebmanagment.userservice.dto.SignupRequest;
import com.cebmanagment.userservice.models.ERole;
import com.cebmanagment.userservice.models.Role;
import com.cebmanagment.userservice.models.User;
import com.cebmanagment.userservice.repositories.RoleRepository;
import com.cebmanagment.userservice.repositories.UserRepository;
import com.cebmanagment.userservice.services.UserDetailsImpl;
import lombok.AllArgsConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/auth")
@AllArgsConstructor
public class AuthController {


    private UserRepository userRepository;


    private RoleRepository roleRepository;


    private PasswordEncoder encoder;


    private JwtUtils jwtUtils;


    private AuthenticationManager authenticationManager;


    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
    /**
     * Registers a new user in the system.
     *
     * @param signUpRequest the signup request containing username, email, password, and roles.
     * @return ResponseEntity indicating the result of the operation (success or failure message).
     */
    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@RequestBody SignupRequest signUpRequest) {
        logger.info("Registering user: {}", signUpRequest.getUsername());
        logger.debug("Full signup request: {}", signUpRequest);
        if (userRepository.existsByUsername(signUpRequest.getUsername())) {
            return ResponseEntity.badRequest().body("Error: Username is already taken!");
        }

        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            return ResponseEntity.badRequest().body("Error: Email is already in use!");
        }

        // Create new user's account
        User user = new User();
        user.setUsername(signUpRequest.getUsername());
        user.setEmail(signUpRequest.getEmail());
        user.setPassword(encoder.encode(signUpRequest.getPassword()));

        Set<String> strRoles = signUpRequest.getRoles();
        Set<Role> roles = new HashSet<>();

        if (strRoles == null) {
            Role userRole = roleRepository.findByName(ERole.USER)
                    .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
            roles.add(userRole);
        } else {
            strRoles.forEach(role -> {
                switch (role.toLowerCase()) {
                    case "manager":
                        Role managerRole = roleRepository.findByName(ERole.MANAGER)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(managerRole);
                        break;
                    case "secretary":
                        Role secretaryRole = roleRepository.findByName(ERole.SECRETARY)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(secretaryRole);
                        break;
                    case "accountant":
                        Role accountantRole = roleRepository.findByName(ERole.ACCOUNTANT)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(accountantRole);
                        break;
                    default:
                        Role userRole = roleRepository.findByName(ERole.USER)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(userRole);
                }
            });
        }

        user.setRoles(roles);
        userRepository.save(user);

        return ResponseEntity.ok("User registered successfully!");
    }

    /**
     * Authenticates a user and generates a JWT token.
     *
     * @param loginRequest the login request containing username and password.
     * @return JwtResponse containing the generated token and user details.
     */
    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
        System.out.println("Login endpoint hit: " + loginRequest);
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);

        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        List<String> roles = userDetails.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();

        return ResponseEntity.ok(new JwtResponse(jwt, userDetails.getUsername(), new HashSet<>(roles)));
    }
}
