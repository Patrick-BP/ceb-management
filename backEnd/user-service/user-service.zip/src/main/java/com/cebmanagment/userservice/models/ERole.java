package com.cebmanagment.userservice.models;

/**
 * Enum representing the predefined roles in the system.
 */
public enum ERole {
    USER,
    MANAGER,
    SECRETARY,
    ACCOUNTANT
}
